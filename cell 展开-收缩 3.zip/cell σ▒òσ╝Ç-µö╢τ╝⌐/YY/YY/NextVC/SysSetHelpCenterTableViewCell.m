//
//  SysSetHelpCenterTableViewCell.m
//  TVXiaoZhen
//
//  Created by ArrQ on 2017/7/25.
//  Copyright © 2017年 ArrQ. All rights reserved.
//

#import "SysSetHelpCenterTableViewCell.h"

@implementation SysSetHelpCenterTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self customSubViews];
        
    }
    
    return self;
    
}


- (void)customSubViews{
    
    UILabel *lable_000 = [[UILabel alloc]init];
    
    lable_000.text = @"遇到手机绑定问题怎么办？";
    [lable_000 sizeToFit];
    
    lable_000.font = [UIFont systemFontOfSize:14];
    lable_000.textAlignment = NSTextAlignmentLeft;
    lable_000.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    
    [self.contentView addSubview:lable_000];
    _titleLab = lable_000;
    
    
    
    UILabel *lable_subtitle = [[UILabel alloc]init];
    
    lable_subtitle.text = @"展开 - 内容";
    [lable_subtitle sizeToFit];
    lable_subtitle.numberOfLines = 0;
    lable_subtitle.font = [UIFont systemFontOfSize:14];
    lable_subtitle.textAlignment = NSTextAlignmentLeft;
    lable_subtitle.textColor = [UIColor redColor];

    [self.contentView addSubview:lable_subtitle];
    _subTitleLab = lable_subtitle;
    
    
    UILabel *lable_line = [[UILabel alloc]init];
    
    lable_line.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    [self.contentView addSubview:lable_line];
    _lineLab = lable_line;
    
    
    
    UIButton *button_ = [UIButton buttonWithType:UIButtonTypeCustom];
    [button_ setImage:[UIImage imageNamed:@"tv_vedioDetail_Arrow_000"] forState:UIControlStateNormal];
    [button_ setImage:[UIImage imageNamed:@"tv_vedioDetail_Arrow_001"] forState:UIControlStateSelected];

    [button_ addTarget:self action:@selector(btnMoreEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:button_];
    _btnArrow = button_;


    
    
    
}



# pragma mark ---  event --------

- (void)btnMoreEvent:(UIButton *)sender{
    
    sender.tag  = self.cellIndexPath.row;
    sender.selected = !sender.selected;

    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    [dic setObject:[NSNumber numberWithInteger:sender.tag] forKey:@"row"];
    
    [dic setObject:[NSNumber numberWithBool:sender.selected] forKey:@"isShow"];
    
    
    
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(remarksCellShowContrntWithDic:andCellIndexPath:)]) {
        
        
        [self.delegate remarksCellShowContrntWithDic:dic andCellIndexPath:_cellIndexPath];
        
        
        
    }
    
    

}






#pragma mark = 代理
- (void)setCellContent:(NSString *)constr andIsShow:(BOOL)isShow andCellIndexPath:(NSIndexPath *)indexPath {
    
    _subTitleLab.hidden = YES;
    _subTitleLab.text = constr;
    _cellIndexPath = indexPath;
    CGRect rect = [_subTitleLab.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 16, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil];
    
//     这里 设置即可
    
    if (isShow) {
        
        _subTitleLab.hidden = NO;

        [_subTitleLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_left).offset(8);
            
            make.top.equalTo(_titleLab.mas_bottom).offset(20);
            make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH-16, rect.size.height+10));//lable  高度 计算不准确  +10
        }];

        
        
    }else{
    
        _subTitleLab.hidden = YES;

        [_subTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.mas_left).offset(8);
            make.width.mas_equalTo(SCREEN_WIDTH-16);
            
            make.top.equalTo(_titleLab.mas_bottom).offset(0);
            
            
        }];
        
    
    }
    
    
    
}



+ (CGFloat)setCellForHeightWith:(NSString *)contentStr andIsShow:(BOOL)isShow andLableWidth:(CGFloat)width andFont:(CGFloat)font andDefaultHeight:(CGFloat)defaultHeight {
    
    CGRect rect = [contentStr boundingRectWithSize:CGSizeMake(width, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:font]} context:nil];
    
    
    if (isShow) {

        return rect.size.height+defaultHeight;
        
    }else{
        
        return  defaultHeight;
        
        
    }
    
    
    return 60;
    
    
}








# pragma mark ---  lay -------
- (void)layoutSubviews{
    
//    需要展开的  label
    [_subTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(self.mas_left).offset(8);
        make.width.mas_equalTo(SCREEN_WIDTH-16);
        make.top.equalTo(_titleLab.mas_bottom).offset(0);
        
        
    }];
    

//    ----------------------
    
    [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.mas_equalTo(20);
        
        
        make.left.equalTo(self.mas_left).offset(8);

        make.top.equalTo(self.mas_top).offset(20);
        
        
    }];
    
   
    
    [_btnArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        
        
        make.size.mas_equalTo(CGSizeMake(20, 20));
        make.right.equalTo(self.mas_right).offset(-8);
        make.top.equalTo(self.mas_top).offset(20);

        
        
    }];
    
    
    
    
    
    [_lineLab mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.mas_equalTo(1);
        make.right.left.equalTo(self);
        make.bottom.equalTo(self.mas_bottom);
        
    }];
    
    
    
    
}

@end
