//
//  TVSysSetHelpCenterViewController.m
//  TVXiaoZhen
//
//  Created by ArrQ on 2017/7/25.
//  Copyright © 2017年 ArrQ. All rights reserved.
//

#import "TVSysSetHelpCenterViewController.h"
#import "SysSetHelpCenterTableViewCell.h"
@interface TVSysSetHelpCenterViewController ()<UITableViewDelegate,UITableViewDataSource,HelpCenterBtnSelectedDelegate>


@property(nonatomic,strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableDictionary *cellDic;//存放cell视图展开状态的字典
@property (nonatomic, assign) BOOL isShow;//展开状态

@property(nonatomic,strong) NSArray *dataSource;


@end

@implementation TVSysSetHelpCenterViewController


- (NSMutableDictionary *)cellDic {
    if (!_cellDic) {
        self.cellDic = [NSMutableDictionary dictionary];
    }
    return _cellDic;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"帮助";
    
    [self.view addSubview:self.tableView];
    
    [self loadData];
}





#pragma mark ---  tableView delegate


- (UITableView *)tableView {
    if (!_tableView) {
        CGRect frame = [UIScreen mainScreen].bounds;
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        
        [_tableView registerClass:[SysSetHelpCenterTableViewCell class] forCellReuseIdentifier:@"homecell"];
        
        
        
        
    }
    return _tableView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 10;
    
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.dataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    

    
    NSDictionary *dic = [self.dataSource objectAtIndex:indexPath.row];
    NSString *constr = [NSString stringWithFormat:@"%@",dic[@"title"]];
    
//
    BOOL  open = [[self.cellDic objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row]] boolValue];
    
    
//    默认 60  展开是  60+
    return [SysSetHelpCenterTableViewCell setCellForHeightWith:constr andIsShow:open andLableWidth:SCREEN_WIDTH-16 andFont:14 andDefaultHeight:60];


    
    
}






- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    SysSetHelpCenterTableViewCell *homeCell_000 = [tableView dequeueReusableCellWithIdentifier:@"homecell"];
    homeCell_000.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (!homeCell_000) {
        homeCell_000.selectionStyle = UITableViewCellSelectionStyleNone;
        homeCell_000.backgroundColor = [UIColor whiteColor];
        homeCell_000 = [[SysSetHelpCenterTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"homecell"];
        
        
    }
    

    homeCell_000.delegate = self;
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    BOOL  open = [[self.cellDic objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row]] boolValue];

    
    [homeCell_000 setCellContent:dic[@"title"] andIsShow:open andCellIndexPath:indexPath];

    
    
    return homeCell_000;
    
    
}


# pragma mark --- delegate-----

- (void)remarksCellShowContrntWithDic:(NSDictionary *)dic andCellIndexPath:(NSIndexPath *)indexPath{
    
    BOOL is =  [[NSString stringWithFormat:@"%ld", indexPath.row] boolValue];

    
     NSLog(@"返回数据：------  bool = %i",is);
    [self.cellDic setObject:[dic objectForKey:@"isShow"] forKey:[NSString stringWithFormat:@"%@", [dic objectForKey:@"row"]]];
    
     NSLog(@"返回数据：%@",self.cellDic);
    
//    _isShow = [[self.cellDic objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row]] boolValue];// 全选 状态
    
    
    
    [self.tableView reloadData];
    
}








# pragma mark ---  数据源 ------
- (void)loadData{

    NSArray *arr = @[@{@"title":@"点击我没问题---------"},
                     
                     @{@"title":@"请关注 右边的  箭头"},
                     
                     @{@"title":@"应该还是没问题，请关注 右边的  箭头指向"},
                     
                     @{@"title":@"点击我没问题---还是没问题，请关注 右边箭头指向-----点击我没问题---还是没问题，请关注 右边箭头指向"},
                     
                     
                     @{@"title":@"问题来了 箭头 点着 点着  怎么 就 不听使唤了呢--------问题来了 箭头 点着 点着  怎么 就 不听使唤了呢---点击我没问题---还是没问题，请关注 右边箭头指向"},
                     
                     
                     @{@"title":@"问题来了 箭头 点着 点着  怎么 就 不听使唤了呢--------问题来了 箭头 点着 点着  怎么 就 不听使唤了呢---点击我没问题---还是没问题，请关注 右边箭头指向----问题来了 箭头 点着 点着  怎么 就 不听使唤了呢--------问题来了 箭头 点着 点着  怎么 就 不听使唤了呢---点击我没问题---还是没问题，请关注 右边箭头指向"},
                     
                     @{@"title":@"你发现 问题的存在了吗？，"},
                     
                     @{@"title":@"你妹啊，鬼知道啊，你妹啊，"},
                     
                     
                     
                     
                     ];
    
    self.dataSource = [arr copy];
    
    
    

}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
