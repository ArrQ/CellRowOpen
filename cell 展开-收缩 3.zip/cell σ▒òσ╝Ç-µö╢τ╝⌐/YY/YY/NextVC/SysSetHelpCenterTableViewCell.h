//
//  SysSetHelpCenterTableViewCell.h
//  TVXiaoZhen
//
//  Created by ArrQ on 2017/7/25.
//  Copyright © 2017年 ArrQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HelpCenterBtnSelectedDelegate <NSObject>

- (void)remarksCellShowContrntWithDic:(NSDictionary *)dic andCellIndexPath:(NSIndexPath *)indexPath;
@end
@interface SysSetHelpCenterTableViewCell : UITableViewCell


@property(nonatomic,strong) UILabel *titleLab;
@property(nonatomic,strong) UIButton *btnArrow;// 展示更多

@property(nonatomic,strong) UILabel *subTitleLab;

@property(nonatomic,strong) UILabel *lineLab;

@property(nonatomic,assign)id <HelpCenterBtnSelectedDelegate> delegate;
@property (nonatomic, strong)NSIndexPath *cellIndexPath;//当前cell下标

@property (nonatomic, assign) BOOL isSearchState;

- (void)setCellContent:(NSString *)constr andIsShow:(BOOL)isShow andCellIndexPath:(NSIndexPath *)indexPath;

+ (CGFloat)setCellForHeightWith:(NSString *)contentStr andIsShow:(BOOL)isShow andLableWidth:(CGFloat)width andFont:(CGFloat)font andDefaultHeight:(CGFloat)defaultHeight;

@end
